﻿namespace FileExplorer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnOpen = new Button();
            imageList = new ImageList(components);
            listView = new ListView();
            txtPath = new TextBox();
            label1 = new Label();
            lblStatus = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // btnOpen
            // 
            btnOpen.Location = new Point(705, 411);
            btnOpen.Name = "btnOpen";
            btnOpen.Size = new Size(83, 23);
            btnOpen.TabIndex = 0;
            btnOpen.Text = "Open";
            btnOpen.UseVisualStyleBackColor = true;
            btnOpen.Click += btnOpen_Click;
            // 
            // imageList
            // 
            imageList.ColorDepth = ColorDepth.Depth32Bit;
            imageList.ImageSize = new Size(32, 32);
            imageList.TransparentColor = Color.Transparent;
            // 
            // listView
            // 
            listView.LargeImageList = imageList;
            listView.Location = new Point(12, 55);
            listView.MultiSelect = false;
            listView.Name = "listView";
            listView.Size = new Size(776, 333);
            listView.TabIndex = 1;
            listView.UseCompatibleStateImageBehavior = false;
            listView.SelectedIndexChanged += listView_SelectedIndexChanged;
            // 
            // txtPath
            // 
            txtPath.Location = new Point(72, 411);
            txtPath.Name = "txtPath";
            txtPath.Size = new Size(617, 23);
            txtPath.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 414);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 4;
            label1.Text = "Path:";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            lblStatus.ForeColor = Color.Blue;
            lblStatus.Location = new Point(660, 9);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(94, 28);
            lblStatus.TabIndex = 5;
            lblStatus.Text = "00:00:00";
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblStatus);
            Controls.Add(label1);
            Controls.Add(txtPath);
            Controls.Add(listView);
            Controls.Add(btnOpen);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOpen;
        private ImageList imageList;
        private ListView listView;
        private TextBox txtPath;
        private Label label1;
        private Label lblStatus;
        private System.Windows.Forms.Timer timer1;
    }
}